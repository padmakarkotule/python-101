from django.conf.urls import url
from django.urls import path
from rest_framework.urlpatterns import format_suffix_patterns

from myapp import views

urlpatterns = [
   path('network', views.networks),
   path('ip_status', views.ip_status),
   path('reserve/new', views.reserve_ip),
   path('reserve/list', views.reserved_ips_list),
   path('release', views.unreserve_ip),
   # path('organisation', views.get_organisation),
   # path('projects', views.projects_list_post),
   # path('projects/<pk>', views.get_organisation)
]

# urlpatterns = format_suffix_patterns(urlpatterns)
