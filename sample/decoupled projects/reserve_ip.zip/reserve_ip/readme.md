1 GET /api/network?role=Manager  
Response​ : 
```json
{
"result": [
{
"_ref": "network/ZG5zLm5ldHdvcmskMTcyLjI1LjI1LjAvMjQvMA:172.25.25.0/24/default",
"network": "172.25.25.0/24",
"network_view": "default"
}],  
"status": 200
}
```

2 GET /api/ip_status?role=Manager&network=172.25.25.0/24  
Response :  
```json
{
"result": [
{
"_ref": "ipv4address/Li5pcHY0X2FkZHJlc3MkMTcyLjI1LjI1LjAvMA:172.25.25.0",
"ip_address": "172.25.25.0",
"mac_address": "",
"network": "172.25.25.0/24",
"status": "USED",
"created_at": 1585911430
},
{
"_ref": "ipv4address/Li5pcHY0X2FkZHJlc3MkMTcyLjI1LjI1LjEvMA:172.25.25.1",
"ip_address": "172.25.25.1",
"mac_address": "",
"network": "172.25.25.0/24",
"status": "UNUSED","created_at": 1585911430
},
{
"_ref": "ipv4address/Li5pcHY0X2FkZHJlc3MkMTcyLjI1LjI1LjIvMA:172.25.25.2",
"ip_address": "172.25.25.2",
"mac_address": "",
"network": "172.25.25.0/24",
"status": "UNUSED",
"created_at": 1585911430
}]
}
```
3 POST /api/reserve/new?role=Manager  
Body:  
```json
{"ip":["10.71.71.5","10.71.71.8", "10.71.71.1", "10.71.71.2", "10.71.71.0", "172.25.25.6",
"172.25.25.8"],
"userid": "5e5e2db6479496447c8f3a0e"}  

```
Response:  
```json
{
"result": [  
{
"_ref":  
"fixedaddress/ZG5zLmZpeGVkX2FkZHJlc3MkMTAuNzEuNzEuNS4wLi4:10.71.71.5/default",  
"ipv4addr": "10.71.71.5",  
"mac": "00:00:00:00:00:00",  
"username": "ykate",  
"_id": "10.71.71.5",  
"reserved_at": 1585910713.831837,  
"status": 201  
},  
{
"_ref":  
"fixedaddress/ZG5zLmZpeGVkX2FkZHJlc3MkMTAuNzEuNzEuOC4wLi4:10.71.71.8/default",
"ipv4addr": "10.71.71.8",
"mac": "00:00:00:00:00:00",
"username": "ykate",
"_id": "10.71.71.8",
"reserved_at": 1585910727.734474,
"status": 201
},
{"_ref":
"fixedaddress/ZG5zLmZpeGVkX2FkZHJlc3MkMTAuNzEuNzEuMS4wLi4:10.71.71.1/default",
"ipv4addr": "10.71.71.1",
"mac": "00:00:00:00:00:00",
"username": "ykate",
"_id": "10.71.71.1",
"reserved_at": 1585910735.9569416,
"status": 201
},
{
"_ref":
"fixedaddress/ZG5zLmZpeGVkX2FkZHJlc3MkMTAuNzEuNzEuMi4wLi4:10.71.71.2/default",
"ipv4addr": "10.71.71.2",
"mac": "00:00:00:00:00:00",
"username": "ykate",
"_id": "10.71.71.2",
"reserved_at": 1585910740.1049957,
"status": 201
},
{
"Error": "AdmConDataError: None (IBDataConflictError: IB.Data.Conflict:The IP address 10.71.71.0 is not valid for the network 10.71.71.0/24.)",
"code": "Client.Ibap.Data.Conflict",
"text": "The IP address 10.71.71.0 is not valid for the network 10.71.71.0/24.",
"status": 404
},
{
"Error": "AdmConDataError: None (IBDataConflictError: IB.Data.Conflict:IP address 172.25.25.6 is already used by a reservation.)",
"code": "Client.Ibap.Data.Conflict",
"text": "IP address 172.25.25.6 is already used by a reservation.",
"status": 404
},
{
"Error": "AdmConDataError: None (IBDataConflictError: IB.Data.Conflict:IP address 172.25.25.8 is already used by a reservation.)",
"code": "Client.Ibap.Data.Conflict",
"text": "IP address 172.25.25.8 is already used by a reservation.",
"status": 404
}
],
"reserved_ip_success": [
"10.71.71.5","10.71.71.8",
"10.71.71.1",
"10.71.71.2"
],
"reserved_ip_failure": [
"10.71.71.0",
"172.25.25.6",
"172.25.25.8"
]
}

```
4 DELETE /api/release?role=Manager  
Body:  
```json
{"ip":["10.71.71.5","10.71.71.8"], "userid": "5e5e2db6479496447c8f3a0e"}  
```
Response:
```json
[
"ipv4address/Li5pcHY0X2FkZHJlc3MkMTAuNzEuNzEuNS8w:10.71.71.5",
"ipv4address/Li5pcHY0X2FkZHJlc3MkMTAuNzEuNzEuOC8w:10.71.71.8"
]

```


