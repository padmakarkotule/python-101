1 /roles GET:  
Response:  
```json
[
    {
        "_id": {
            "$oid": "5e81d23657737f1b1b91e575"
        },
        "role_name": "test",
        "description": "A test role",
        "created_at": {
            "$date": 1585566259402
        }
    },
    {
        "_id": {
            "$oid": "5e81e46d536a3fff8b87a2c0"
        },
        "role_name": "test1",
        "description": "A test role",
        "created_at": {
            "$date": 1585570925574
        },
        "modified_at": {
            "$date": 1585570925574
        }
    },
    {
        "_id": {
            "$oid": "5eb92966f54e133353e39039"
        },
        "role_name": "Manager",
        "created_at": 1589193062
    }
]
```

2 /roles POST
Body: 
```json
{
"role_name": "sys_admin",
"description": "A system admin role"
}
```

Response: 
```json
{
    "_id": "5edf634b8add57476a69c97d"
}
```

3 /roles/id PATCH:  
Request Body:
```json
{
"role_name": "sys_admin2",
"description": "A system admin role again updated"
}
```
Response:
```json
{
    "_id": {
        "$oid": "5edf634b8add57476a69c97d"
    },
    "role_name": "sys_admin2",
    "description": "A system admin role again updated",
    "created_at": 1591698251,
    "updated_at": 1591698790
}
```

4 /roles/id GET

```json
{
    "_id": {
        "$oid": "5edf634b8add57476a69c97d"
    },
    "role_name": "sys_admin2",
    "description": "A system admin role again updated",
    "created_at": 1591698251,
    "updated_at": 1591698790
}
```

5 /roles/id DELETE
```json
{
    "status": true
}
```