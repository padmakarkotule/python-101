import smtplib
from email import encoders
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase

class Operations:
    def send_email(self):
        mail_content = '''Hello,
        This is a simple mail. There is only text, no attachments are there The mail is sent using Python SMTP library.
        Thank You'''
        # The mail addresses and password
        sender_address = 'senders email id'
        sender_pass = 'senders password'
        receiver_address = 'receivers address'
        message = MIMEMultipart()
        message['From'] = sender_address
        message['To'] = receiver_address
        message['Subject'] = 'A test mail sent by Python. It has an attachment.'  # The subject line
        # The body and the attachments for the mail
        message.attach(MIMEText(mail_content, 'plain'))

        filename = "abc.jpg"
        attachment = open("path to file", "rb")

        mime = MIMEBase('application', 'octet-stream')
        mime.set_payload((attachment).read())

        encoders.encode_base64(mime)
        mime.add_header('Content-Disposition', "attachment; filename= %s" % filename)
        message.attach(mime)

        # Create SMTP session for sending the mail
        session = smtplib.SMTP('smtp.gmail.com', 587)  # use gmail with port
        session.starttls()  # enable security
        session.login(sender_address, sender_pass)  # login with mail_id and password
        text = message.as_string()
        session.sendmail(sender_address, receiver_address, text)
        session.quit()
        print('Mail Sent')
#
# if __name__ == "__main__":
#     ops = Operations()
#     ops.send_email()