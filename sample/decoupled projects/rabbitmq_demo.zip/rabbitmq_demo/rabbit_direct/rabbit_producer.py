from kombu import Connection, Exchange, Producer, Queue

rabbit_url = 'amqp://localhost'
rabbit_port = '5672'

exchange_name = 'exchange_hub'
exchange_type = 'direct'

routing_key_IPAM = 'ipam'
routing_key_reporting = 'reporting'

queue_IPAM = 'ipam_queue'
queue_reporting = 'reporting'

#create connection and channel
# rabbit_url = 'amqp://localhost:5672/'
conn = Connection(rabbit_url+':'+rabbit_port)
channel = conn.channel()

#create exchange and queue
task_exchange = Exchange(exchange_name, type=exchange_type)
ipam_queue = Queue(queue_IPAM, task_exchange, routing_key = routing_key_IPAM)
reporting_queue = Queue(queue_reporting, task_exchange, routing_key = routing_key_reporting)

#create producer and bind queue and declare if not present already
producer = Producer(exchange=task_exchange, channel=channel, routing_key= 'message_1')
ipam_queue.maybe_bind(conn)
# ipam_queue.declare()
reporting_queue.maybe_bind(conn)
# reporting_queue.declare()


payload1 = {"type": "handshake", "content": "ipam"}
payload2 = {"type": "handshake", "content": "report"}

#publish payload, it wont publish if queue is not created
producer.publish(payload1, exchange=exchange_name, routing_key=routing_key_IPAM)
producer.publish(payload2, exchange=exchange_name, routing_key=routing_key_reporting)


