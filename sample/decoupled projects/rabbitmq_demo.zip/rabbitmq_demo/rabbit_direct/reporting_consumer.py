from kombu import Connection, Exchange, Queue, Consumer
# rabbit_url = 'amqp://localhost:5672/'
# conn = Connection(rabbit_url)
#
# task_exchange = Exchange("msgs", type="direct")
# queue_msg_1 = Queue("messages_2", task_exchange, routing_key = 'message_2')
#
# def process_message(body, message):
#   print('The body is {}'.format(body))
#   message.ack()
# with Consumer(conn, queues=queue_msg_1, callbacks=[process_message]):
#   conn.drain_events(timeout=5670)
from kombu.mixins import ConsumerMixin
from rabbit_direct.operations import Operations

from kombu import BrokerConnection, Exchange, Queue
from kombu.utils.debug import setup_logging

rabbit_url = 'amqp://localhost'
rabbit_port = '5672'

exchange_name = 'exchange_hub'
exchange_type = 'direct'

routing_key_IPAM = 'ipam'
routing_key_reporting = 'reporting'

queue_IPAM = 'ipam_queue'
queue_reporting = 'reporting'


task_exchange = Exchange(exchange_name, type=exchange_type)
queue_msg_1 = Queue(queue_reporting, task_exchange, routing_key = routing_key_reporting)


class Consumer(ConsumerMixin):
  def __init__(self, connection):
    self.connection = connection
    return

  #read fromm queue, call on message
  def get_consumers(self, Consumer, channel):
    return [Consumer(queue_msg_1, callbacks=[self.on_message])]

  def on_message(self, body, message):
    if body['content'] == 'ipam':
      ops = Operations()
      ops.send_email()
      print("---------IPAM------------")

    if body['content'] == 'report':
      print("---------Report------------")

    message.ack()
    return


if __name__ == "__main__":
  setup_logging(loglevel="DEBUG")

  #create connection
  with BrokerConnection("amqp://localhost:5672/") as connection:
    try:
      Consumer(connection).run()
    except KeyboardInterrupt:
      print("bye bye")

