from __future__ import with_statement
# from kombu_ex.fanout.queues import task_exchange

from kombu.common import maybe_declare
from kombu.pools import producers
from kombu import BrokerConnection, Exchange, Queue, Connection, Producer


rabbit_url = 'amqp://localhost:5672/'
conn = Connection(rabbit_url)
channel = conn.channel()

task_exchange = Exchange("ce", type="fanout")
queue_events_db = Queue("events.db", task_exchange)
queue_events_notify = Queue("events.notify", task_exchange)

producer = Producer(exchange=task_exchange, channel=channel, routing_key='user.write')
queue_events_db.maybe_bind(conn)
queue_events_db.declare()

maybe_declare(task_exchange, producer.channel)

payload = {"operation": "create", "content": "the object"}
producer.publish(payload, exchange='ce', routing_key='user.write')
print("pub")

payload = {"operation": "update", "content": "updated fields", "id": "id of the object"}
producer.publish(payload, exchange='ce', routing_key='user.write')



print("pub")