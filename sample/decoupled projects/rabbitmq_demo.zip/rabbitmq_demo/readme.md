#### **Installing RabbitMQ server on Ubuntu 18**

1. Follow steps given in this blog:
https://tecadmin.net/install-rabbitmq-server-on-ubuntu/

2. This will install erlang framework and rabbitmq both.

3. Access Server UI on this path: 
http://localhost:15672/  
Everything including connections, channels, exchanges, queues can be handled from UI

4. One exchange can serve only one type of exchange. It can be either **direct, fanout, topic or header**

5. Replace localhost and port with respective machine IP and port it is running on.

6. pip install -r requirements.txt

7 run rabbit_producer.py

8. run consumer.py