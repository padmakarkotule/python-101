import yaml

class Configs:
    with open("config.yaml", 'r') as stream:
        yaml_con = yaml.safe_load(stream)
        print(yaml_con)