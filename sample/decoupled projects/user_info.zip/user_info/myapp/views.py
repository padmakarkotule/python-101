import json
import logging

import time
from bson import ObjectId, json_util
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from pymongo import ReturnDocument
from rest_framework.decorators import api_view
from myapp.searializers import UsersSerializer
from utils.environment_configs import EnvironmentConfigs as env
from utils.mongo_utils import MongoQueryUtils
from google.cloud import storage

logger = logging.getLogger("django")

mongo_utils = MongoQueryUtils()
role_collection = mongo_utils.get_collection_handle(env.mongo_roles_collection)
users_collection = mongo_utils.get_collection_handle(env.mongo_users_collection)
projects_collection = mongo_utils.get_collection_handle(env.mongo_projects_collection)

# Create and GET all users
@csrf_exempt
@api_view(['GET', 'POST'])
def users_list_post(request):
    logger.info(request)
    try:
        if (request.method == 'GET'):
            from bson import json_util
            user_list = []
            data_cursor = users_collection.find()
            for data in data_cursor:
                user_list.append(json.loads(json_util.dumps(data)))
            return JsonResponse(user_list, status=200, safe=False)
        elif (request.method == 'POST'):
            if all(key in request.data for key in ('username', 'role_name')):
                existing_user = users_collection.find_one({'username': request.data['username']})
                existing_role = role_collection.find_one({'role_name': request.data['role_name']})
                if not existing_user:
                    if existing_role:
                        request.data['created_at'] = int(time.time())
                        serializer = UsersSerializer(data=request.data)
                        if (serializer.is_valid() == True and len(serializer.errors) == 0):
                            storage_client = storage.Client.from_service_account_json(env.google_creds)
                            bucket = storage_client.get_bucket(env.bucket_id)
                            blob = bucket.blob(request.data['username']+'/')
                            blob.upload_from_string('')
                            request.data['folder_path'] = request.data['username']+'/'
                            data = users_collection.save(request.data)
                            jsondata = {"_id": str(data)}
                            return JsonResponse(jsondata,status=201)
                        else:
                            jsondata = serializer.errors
                            logger.error(jsondata)
                            return JsonResponse(jsondata, status=422)
                    else:
                        jsondata = {"error": "Role does not exist."}
                        logger.error(jsondata)
                        return JsonResponse(jsondata, status=422)

                else:
                    jsondata = {"error": "User already exist."}
                    logger.error(jsondata)
                    return JsonResponse(jsondata, status=422)
            else:
                jsondata = {"error": "Either username or role_name is missing from request."}
                logger.error(jsondata)
                return JsonResponse(jsondata, status=422)
    except Exception as e:
        logger.exception(e)
        jsondata = {"Error": e}
        return JsonResponse(jsondata, status=400)

#'GET', 'PATCH', 'DELETE' users by Id
@csrf_exempt
@api_view(['GET', 'PATCH', 'DELETE'])
def users_operations(request, pk):
    logger.info(request.data)
    try:
        if (request.method == 'GET'):
            data = users_collection.find_one({'_id': ObjectId(pk)})
            if data:
                jsondata = json.loads(json_util.dumps(data))
                return JsonResponse(jsondata, status=200)
            else:
                jsondata = {"error": "User with given ID not found."}
                logger.error(jsondata)
                return JsonResponse(jsondata, status=404)
        elif (request.method == 'PATCH'):
            serializer = UsersSerializer(data=request.data, partial=True)
            if (serializer.is_valid() == True):
                request.data['updated_at'] = int(time.time())
                update_object = users_collection.find_one_and_update({'_id': ObjectId(pk)}, {'$set': request.data}, return_document=ReturnDocument.AFTER)
                # data = users_collection.find_one({'_id': ObjectId(pk)})
                jsondata = json.loads(json_util.dumps(update_object))
                return JsonResponse(jsondata, status=200)
            else:
                jsondata = {"error": "Bad request body."}
                logger.error(jsondata)
                return JsonResponse(jsondata, status=400)
        elif (request.method == "DELETE"):
            delete = users_collection.delete_one({'_id': ObjectId(pk)})
            if (delete.acknowledged == True):
                jsondata = {"status": delete.acknowledged}
                return JsonResponse(jsondata, status=200)
            else:
                jsondata = {"error": "Resource does not exist."}
                logger.error(jsondata)
                return JsonResponse(jsondata, status=404)
    except Exception as e:
        jsondata = {"Exception": e}
        logger.exception(jsondata)
        return JsonResponse(jsondata, status=400)
