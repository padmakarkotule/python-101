from django.conf.urls import url
from django.urls import path
from rest_framework.urlpatterns import format_suffix_patterns

from myapp import views

urlpatterns = [
   path('users', views.users_list_post),
   path('users/<pk>', views.users_operations),
]

# urlpatterns = format_suffix_patterns(urlpatterns)
