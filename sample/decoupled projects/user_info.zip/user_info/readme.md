1 /users GET
Response:
```json
[
    {
        "_id": {
            "$oid": "5ea02622507c63fe614c02fc"
        },
        "username": "YK",
        "firstname": "Yogesh",
        "lastname": "kate",
        "a": "s",
        "role_name": "Manager",
        "created_at": 1587553826,
"folder_path": "YK/"
    },
    {
        "_id": {
            "$oid": "5eb92981f54e133353e3903a"
        },
        "username": "ykate",
        "role_name": "Manager",
        "firstname": "Yogesh",
        "lastname": "last_name",
        "created_at": 1589193068,
        "folder_path": "ykate/"
    }
]
```
2 /users POST

Request Body:
```json
{
	"username": "YK123",
	"role_name": "Manager",
	"lastname": "KATE",
	"firstname": "Yogesh",
	"groups": "team xyz"
}
```
Response Body:
```json
{
    "_id": "5edf6cb787ec7f2d92da23d1"
}
```
3 /users/id PATCH

Request Body:
```json
{
	"username": "YK123",
	"role_name": "admin",
	"lastname": "KATE",
	"firstname": "Yogesh",
	"groups": "team xyz"
}
```

Response:
```json
{
    "_id": {
        "$oid": "5edf6cb787ec7f2d92da23d1"
    },
    "username": "YK123",
    "role_name": "admin",
    "lastname": "KATE",
    "firstname": "Yogesh",
    "groups": "team xyz",
    "created_at": 1591700662,
    "folder_path": "YK123/",
    "updated_at": 1591701331
}
```
/users/id GET:

Response:
```json
{
    "_id": {
        "$oid": "5edf6cb787ec7f2d92da23d1"
    },
    "username": "YK123",
    "role_name": "admin",
    "lastname": "KATE",
    "firstname": "Yogesh",
    "groups": "team xyz",
    "created_at": 1591700662,
    "folder_path": "YK123/",
    "updated_at": 1591701331
}
```

/users/id DELETE

Response:
```json
{
    "status": true
}
```